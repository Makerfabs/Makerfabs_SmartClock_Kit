
0x1000 SmartClock.ino.bootloader.bin 
0x8000 SmartClock.ino.partitions.bin 
0xe000 boot_app0.bin 
0x10000 SmartClock.ino.bin 
